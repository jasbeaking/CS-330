///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager, Camera* camera)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0; // initialize texture count

	m_Camera = camera; // store the camera pointer
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	size_t index = 0;  // use size_t instead of int
	bool bFound = false;
	while (index < m_objectMaterials.size() && !bFound)
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	// Each mesh needs to be loaded once in order to be used in the scene.
	// Load the basic shapes into memory
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();

	// Load textures into OpenGL memory.
	// "metallic.jpeg" is assigned the tag "metalArmTexture" for reference.
	// By storing a tag, we can apply this texture to any mesh later using SetShaderTexture().
	// The image is flipped vertically during loading to match OpenGL's coordinate system.
	CreateGLTexture("textures/metallic.jpeg", "metalArmTexture");

	// Setup lights for the scene
	SetupSceneLights();
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// call each of the necessary draw functions from RenderScene
	drawDeskSurface();
	drawMonitor();
	drawLaptop();
	drawKeyboard();
	drawMouse();
	drawIndexCardStacks();
	drawChargingStation();
	drawPencilHolder();
	drawDeskLamp();

	// declare the variables for the transformations
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	glm::vec3 scaleXYZ(20.0f, 1.0f, 10.0f); // desk dimensions

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// --- Draw Milestone 3 Ground Plane ---
	glm::vec3 groundScale(50.0f, 1.0f, 50.0f);
	glm::vec3 groundPos(0.0f, -1.0f, 0.0f); // slightly below desk
	SetTransformations(groundScale, 0.0f, 0.0f, 0.0f, groundPos);
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	// --- Draw Desk Plane ---
	glm::vec3 deskScale(20.0f, 1.0f, 10.0f); // thinner desk plane
	glm::vec3 deskPos(0.0f, 0.0f, 0.0f);
	SetTransformations(deskScale, 0.0f, 0.0f, 0.0f, deskPos);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // color of desk
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
}
/***********************************************************
 * Desk Lamp Functions
 ***********************************************************/

 // Draw the lamp base
void SceneManager::drawLampBase()
{
	glm::vec3 offset(-3.0f, 0.0f, 0.0f); // move lamp left on desk
	SetTransformations(glm::vec3(1.0f, 0.2f, 1.0f), 0, 0, 0, glm::vec3(0, 0.1f, 0) + offset);
	SetShaderColor(0.7f, 0.7f, 0.7f, 1.0f); // medium gray for base
	m_basicMeshes->DrawCylinderMesh();
}

// Draw the lamp arm
void SceneManager::drawLampArm()
{
	glm::vec3 offset(-3.0f, 0.0f, 0.0f);
	// --- Lower segment of the arm---
	float lowerLength = 1.0f;
	glm::vec3 scaleLower(0.1f, lowerLength, 0.1f); // thin cylinder
	glm::vec3 posLower(0.0f, 0.1f + lowerLength / 2.0f, 0.0f); // center at midpoint
	float lowerRot = -30.0f; // tilt for realistic bend
	// Apply the metal texture loaded earlier.
	// This tells the shader to use "metalArmTexture" for the next draw call.
	SetShaderTexture("metalArmTexture");
	// Set transformations and draw the lower arm
	SetTransformations(scaleLower, 0.0f, 0.0f, lowerRot, posLower + offset);
	m_basicMeshes->DrawCylinderMesh();

	// --- Upper segment of the arm---
	float upperLength = 1.0f;
	glm::vec3 scaleUpper(0.1f, upperLength, 0.1f);

	// Calculate position so it connects to end of lower segment
	float angleRad = glm::radians(-lowerRot); 
	float offsetX = 0.0f; // arm is bending in Z, so X stays 0
	float offsetY = lowerLength * cos(angleRad); // vertical offset from lower segment
	float offsetZ = lowerLength * sin(angleRad); // horizontal offset from lower segment

	glm::vec3 posUpper(0.5f + offsetX, 0.1f + lowerLength + upperLength / 2.0f * cos(angleRad), offsetZ);
	float upperRot = 30.0f; // tilt relative to lower segment
	// Apply same metal texture to upper arm
	SetShaderTexture("metalArmTexture");
	// Set transformations and draw the upper arm
	SetTransformations(scaleUpper, 0.0f, 0.0f, upperRot, posUpper + offset);
	m_basicMeshes->DrawCylinderMesh();
}

// Draw the hinge connecting arm segments
void SceneManager::drawLampShade()
{
	glm::vec3 offset(-3.0f, 0.0f, 0.0f);
	glm::vec3 scaleXYZ(0.5f, 0.5f, 0.5f);
	glm::vec3 positionXYZ(-0.3f, 2.6f, 0.0f); // position on top of arm
	float Xrot = -90.0f; // tilt cone to point down
	SetTransformations(scaleXYZ, Xrot, 0.0f, 0.0f, positionXYZ + offset);
	SetShaderColor(0.9f, 0.85f, 0.7f, 1.0f); // light brown/cream color
	m_basicMeshes->DrawConeMesh();
}

void SceneManager::drawLampHinge()
{
	glm::vec3 offset(-3.0f, 0.0f, 0.0f);
	glm::vec3 scaleXYZ(0.15f, 0.15f, 0.15f);
	glm::vec3 positionXYZ(-0.1f, 2.5f, 0.0f); // align hinge with arm and shade
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ + offset);
	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f); // light gray
	m_basicMeshes->DrawSphereMesh();
}

// Draw the entire lamp by combining all parts
void SceneManager::drawDeskLamp()
{
	drawLampBase(); // base cylinder
	drawLampArm(); // two-segment arm
	drawLampShade(); // conical shade
	drawLampHinge(); // spherical hinge
}

void SceneManager::drawMonitor()
{
	// Monitor composed of a screen box and stand
	// Screen
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetTransformations(glm::vec3(2.5f, 1.5f, 0.1f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 2.0f, -3.0f));
	m_basicMeshes->DrawBoxMesh();

	// Stand
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	SetTransformations(glm::vec3(0.1f, 0.8f, 0.1f), 0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 1.0f, -3.0f));
	m_basicMeshes->DrawCylinderMesh();
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method defines and enables the light sources
 *  that illuminate the 3D scene.
 *  Up to four lights can be configured, but here we use two:
 *  one main white light (like from the desk lamp)
 *  and one soft blue light to add fill lighting.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Tell the shader to render using lighting instead of flat color.
	// Without this, the scene would look dark or unlit.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/***********************************************************
	 * Light 1 - Primary white light (main light source)
	 * Positioned near the desk lamp to act as its light bulb.
	 ***********************************************************/
	m_pShaderManager->setVec4Value("light1.position", glm::vec4(-3.0f, 3.0f, 3.0f, 1.0f));
	m_pShaderManager->setVec4Value("light1.ambientColor", glm::vec4(0.2f, 0.2f, 0.2f, 1.0f));   // low ambient brightness
	m_pShaderManager->setVec4Value("light1.diffuseColor", glm::vec4(0.8f, 0.8f, 0.8f, 1.0f));   // strong white diffuse
	m_pShaderManager->setVec4Value("light1.specularColor", glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));  // shiny reflections

	/***********************************************************
	 * Light 2 - Secondary blue-tinted light (fill light)
	 * Adds a cool tone and prevents harsh shadows by softly
	 * illuminating the scene from the opposite side.
	 ***********************************************************/
	m_pShaderManager->setVec4Value("light2.position", glm::vec4(3.0f, 2.0f, 2.0f, 1.0f));
	m_pShaderManager->setVec4Value("light2.ambientColor", glm::vec4(0.1f, 0.1f, 0.3f, 1.0f));   // subtle blue ambient
	m_pShaderManager->setVec4Value("light2.diffuseColor", glm::vec4(0.3f, 0.3f, 1.0f, 1.0f));   // cool blue diffuse
	m_pShaderManager->setVec4Value("light2.specularColor", glm::vec4(0.5f, 0.5f, 1.0f, 1.0f));  // bluish highlights
}

