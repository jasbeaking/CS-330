#pragma once

// Minimal globals so the project can compile
const float CAMERA_SPEED = 2.5f;
const float MOUSE_SENSITIVITY = 0.1f;

